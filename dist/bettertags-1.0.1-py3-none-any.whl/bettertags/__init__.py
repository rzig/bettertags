def casefold(tag: str):
    return tag.casefold()